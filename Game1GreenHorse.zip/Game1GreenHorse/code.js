setScreen("background");
playSound("assets/1minuteofsilenthill.mp3", true);
timedLoop(5000, function() {
  hideElement("eyeleft");
  hideElement("eyeright");
  timedLoop(2500, function() {
    showElement("eyeleft");
    showElement("eyeright");
  });
});
onEvent("background", "keydown", function(event) {
	if (event.key == "Left") {
	  console.log("Left Arrow Pressed");
	  setPosition("shield", 70, 145, 100, 100);
	}
});
onEvent("background", "keydown", function(event) {
	if (event.key == "Down") {
	  console.log("Down Arrow Pressed");
	  setPosition("shield", 120, 225, 100, 100);
	}
});
onEvent("background", "keydown", function(event) {
  if (event.key == "Right") {
    console.log("Right Arrow Pressed");
    setPosition("shield", 165, 145, 100, 100);
  }
});
onEvent("background", "keydown", function(event) {
  if (event.key == "Up") {
    console.log("Up Arrow Pressed");
    setPosition("shield", 120, 85, 100, 100);
  }
});
onEvent("background", "keydown", function(event){
  if (event.key == " ") {
    console.log("Spacebar Pressed");
    timedLoop(30, function() {
      setPosition("gluedown", getXPosition("gluedown") + 0, getYPosition("gluedown") + -5, 80, 80);
    });
  }
});
timedLoop(1, function() {
  if (getYPosition("gluedown") == getYPosition("horsecharacter") + 70) {
    deleteElement("gluedown");
    playSound("assets/monsterscream.mp3", false);
    setScreen("gameover");
  }
});
timedLoop(1, function() {
  if (getXPosition("glueleft") == getXPosition("horsecharacter") - 40) {
    setPosition("glueleft", 1000000000, 100000000, 100, 100);
    playSound("assets/monsterscream.mp3", false);
    setScreen("gameover");
  }
});
timedLoop(1, function() {
  if ((getYPosition("gluedown")) <= (getYPosition("shield") + 60)) {
    setPosition("gluedown", 10000000, 100000000, 100, 100);
  }
});
timedLoop(1, function() {
  
});
onEvent("background", "keydown", function(event){
  if (event.key == " ") {
    console.log("Spacebar Pressed");
    timedLoop(100, function() {
      setPosition("glueleft", getXPosition("glueleft") + 5, getYPosition("glueleft") + 0, 80, 80);
    });
  }
});
timedLoop(1, function() {
  if ((getXPosition("glueleft")) >= getXPosition("shield") - 20) {
    setPosition("glueleft", 10000000, 100000000, 100, 100);
  }
});
timedLoop(1, function() {
  if (getXPosition("glueright") == getXPosition("horsecharacter") + 30) {
    deleteElement("glueright");
    playSound("assets/monsterscream.mp3", false);
    setScreen("gameover");
  }
});
timedLoop(1, function() {
  if (getYPosition("glueup") == getYPosition("horsecharacter") - 40) {
    deleteElement("glueup");
    playSound("assets/monsterscream.mp3", false);
    setScreen("gameover");
  }
});
onEvent("background", "keydown", function(event){
  if (event.key == " ") {
    console.log("Spacebar Pressed");
    timedLoop(80, function() {
      setPosition("glueright", getXPosition("glueright") - 5, getYPosition("glueright") + 0, 80, 80);
    });
  }
});
timedLoop(1, function() {
  if ((getXPosition("glueright")) <= (getXPosition("shield") + 20)) {
    setPosition("glueright", 10000000, 100000000, 100, 100);
  }
});
onEvent("background", "keydown", function(event){
  if (event.key == " ") {
    console.log("Spacebar Pressed");
    timedLoop(430, function() {
      setPosition("glueup", getXPosition("glueup") + 0, getYPosition("glueup") + 5, 80, 80);
    });
  }
});
timedLoop(1, function() {
  if ((getYPosition("glueup")) >= (getYPosition("shield") - 20)) {
    setPosition("glueup", 10000000, 100000000, 100, 100);
  }
});
timedLoop(1, function() {
  if (getYPosition("glueup") > getYPosition("horsecharacter")) {
    stopSound("assets/1minuteofsilenthill.mp3");
    playSound("assets/harpy-wheels-victory.mp3", false);
    setScreen("youarewinner");
  }
});
